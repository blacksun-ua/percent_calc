All our resources are royalty free for use in both personal and commercial projects.


You can modify any resources to your liking to fit into your project, we are however not legally reliable for any misuse of our resources.


We do not ask for you to include any attribution or link back to Pixeden.com, we do however appreciate if you do credit our resources or/and help spread the word about us.



You cannot however redistribute, resell, lease, license, sub-license or offer our resources to any third party. This includes uploading our resources to another website or media-sharing tool, and offering our resources as a separate attachment from any of your work.

If you would like to share one of our resource you can do so making a link to the specific resource page on Pixeden.com.



Find more great resources @ Pixeden.com.


Sincerely,
The Pixeden Team.